package com.example.EmployeeManagement.Controller;

import com.example.EmployeeManagement.EmployeeRepository;
import com.example.EmployeeManagement.employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

@Controller
@Transactional
public class EmployeeController {

@PersistenceContext
    EntityManager entityManager;

        @Autowired
        EmployeeRepository rep;


    @RequestMapping(value = "/add",method = RequestMethod.GET)
    public String ShowAddEmployeePage(){

        return "add";
    }


    @RequestMapping(value = "/add",method = RequestMethod.POST)
        public String AddAnEmployee(employee emp){
           // rep.save(emp);
            return "welcome";
        }

    @RequestMapping(value = "/show",method = RequestMethod.GET)
    public String ListAllEmployees(ModelMap model){
       model.put("emp",rep.findAll());
        return "show";
    }

    @RequestMapping(value = "/remove",method = RequestMethod.GET)
    public String rempage(ModelMap model){

        return "remove";
    }

    @RequestMapping(value = "/remove",method = RequestMethod.POST)
    public String remove(@RequestParam String empname,employee employee){
        entityManager.persist(employee);
         rep.deleteByEmpname(empname);
        return "welcome";
    }




}
