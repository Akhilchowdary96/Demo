package com.example.EmployeeManagement;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<employee,Integer> {
    employee findByEmpname(String empname);
void deleteByEmpname(String empname);
}