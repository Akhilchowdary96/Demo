package com.example.EmployeeManagement;
import org.junit.Assert;
import org.junit.Test;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
//import org.junit.jupiter.api.Test;


import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmployeeManagementApplicationTests {

	@Autowired
	private EmployeeRepository repo;


	@Test
	public void testcreate(){
		employee emp = new employee();
		emp.setEmpname("Virat");
		emp.setDesig("Captain");
		emp.setEmptype("Full-time");
		emp.setStatus("Active");
		repo.save(emp);
        assertNotNull(repo.findByEmpname("Virat"));
	}

	@Test
	public void testgetters(){
		employee emp = new employee();
		emp.setEmpname("Akhil");
		Assert.assertEquals("Akhil", emp.getEmpname());
        emp.setDesig("employee");
		Assert.assertEquals("employee", emp.getDesig());
		emp.setEmptype("fulltime");
		Assert.assertEquals("fulltime", emp.getEmptype());
		emp.setStatus("Active");
		Assert.assertEquals("Active", emp.getStatus());
	}




}
